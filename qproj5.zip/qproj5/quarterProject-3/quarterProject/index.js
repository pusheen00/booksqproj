//Urvi Awasthi, Clara Robin, Amanda Wong; Quarter Project; May 13th, 2019
	//backend for mongodb and nodejs, making the books database from a json file, and then rendering that JSON file onto an HTML template

//requiring mongo and all of the other required variables 
var bodyParser = require('body-parser');
var mongo = require('mongodb');
var express = require('express');
var app = express();
var fs = require('fs');
var paypal = require('paypal-rest-sdk');  
var readline = require ('readline'); 
app.use(bodyParser.urlencoded({ extended: true }));

// setting up the ejs template engine
app.set('view engine', 'ejs');

//prerequisites
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";

//for the css
app.use(express.static(__dirname + '/public'));
app.use(express.static(__dirname + '/views'));

//create the database and put the JSON data into the database
//reading the json file
var rawdata = fs.readFileSync('./views/books.json', 'utf8'); 
var jsonData = JSON.parse(rawdata);

var dbo;
//creating a database, dbo, and connecting to that database
MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  dbo = db.db("QuarterProjectDatabase");
  //creating a collection where the book data will be stored
  dbo.createCollection("books", function(err, res) {
	if (err) throw err;
	console.log("Collection created!");
	//inserting data in books collection 
	dbo.collection('books').insertMany(jsonData, function(err, res){
		if (err) {
		  console.log("Cannot insert duplicates, document already exists");
		  return;
		};
		console.log(res.insertedCount+ " documents inserted");
		});
  }); 
});

app.get("/", function (req, res) {
	res.render("index");
});

//puts the books from the JSON file into the webpage 
app.get("/purchase", function(req, res) {
	MongoClient.connect(url, function(err, db) {
	  if (err) throw err;
	  var dbo = db.db("QuarterProjectDatabase");
	  dbo.collection("books").find({}).toArray(function(err, result) {
		if (err) throw err;	
		res.render('purchase', {
			result: result
		});
		db.close();
	  });
	});
});

//loads the donate book page when someone clicks the link to that page
app.get("/donate", function (req, res) {
	res.render('donate.ejs');
});

//adds a book to the book collection 
app.post('/donatebook', (req, res) => {
	const condition = req.body.condition;
	switch (condition)
	{
		case "Brand New":
			req.body.price = "15.00";
			break;
		case "Like New":
			req.body.price = "10.00";
			break;
		case "Very Good":
			req.body.price = "7.00";
			break; 
		case "Good":
			req.body.price = "6.00";
			break; 
		case "Acceptable":
			req.body.price = "5.00";
			break; 
	}	
    dbo.collection('books').insertOne(req.body, (err, result) =>{
      if (err) return console.log(err);
      res.render("donate");
    });
});

/*paypal.configure({
  'mode': 'sandbox', //sandbox or live
  'client_id': 'Aecmth0rnbryKuaepSfyEAHUg1Cf9TQV2JGLthXbTqc4Z76i7YLOVZ4iPQmVO6pzAPalhQYD21TCAxtp',
  'client_secret': 'EGln9cNKxpG5mHKtOIS_bunn1CPfrJ5MxoTnCxpL0IGzZqVtrxzKMZz4H8FWgNVQXslAodUvquZW2iBT'
  });

app.post('/pay', function( _req, res) {
  console.log('sending to ./pay');
	var create_payment_json = {
    "intent": "sale",
    "payer": {
        "payment_method": "paypal"
    },
    "redirect_urls": {
        "return_url": "http://localhost:8082/success",
        "cancel_url": "http://localhost:8082/cancel"
    },
    "transactions": [{
        "item_list": {
            "items": [{
                "name": "ItemName",
                "sku": "ItemSku",
                "price": "10.00",
                "currency": "USD",
                "quantity": 1
            }]
        },
        "amount": {
            "currency": "USD",
            "total": "10.00"
        },
        "description": "This is the payment description."
    }]
  };

  paypal.payment.create(create_payment_json, function (error, payment) {
    if (error) {
        throw error;
    } else {
        for (var i = 0; i < payment.links.length; i++){
          if (payment.links[i].rel == 'approval_url'){
            res.redirect(payment.links[i].href)
          }
        }
    }
  });

});

app.get('/success', (req, res) => {
  const payerId = req.query.PayerID;
  const paymentId = req.query.paymentId;

  const execute_payment_json = {
    "payer_id": payerId,
    "transactions": [{
        "amount": {
            "currency": "USD",
            "total": "10.00"
        }
    }]
  };

  paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
    if (error) {
        console.log(error.response);
        throw error;
    } else {
        //console.log(JSON.stringify(payment));
        res.send('Success');
    }
});
});

app.get('/cancel', function( _req, res) {
	res.send('cancel');
}); */



//live at port 8082
app.listen(8082);
console.log('Live at 8082');

